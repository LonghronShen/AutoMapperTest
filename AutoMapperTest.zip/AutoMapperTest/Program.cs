﻿using AutoMapper;
using System;
using System.Linq;
using System.Runtime.CompilerServices;

namespace AutoMapperTest
{

    internal class AModel
    {

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public override string ToString()
        {
            return $"A: Field1 = {this.Field1}, Field2 = {this.Field2}";
        }

    }

    internal class BModel
    {

        public string Field3 { get; set; }

        public string Field4 { get; set; }

        public override string ToString()
        {
            return $"B: Field1 = {this.Field3}, Field2 = {this.Field4}";
        }

    }

    internal class CModel
    {

        public string Field5 { get; set; }

        public string Field6 { get; set; }

        public override string ToString()
        {
            return $"C: Field1 = {this.Field5}, Field2 = {this.Field6}";
        }

    }

    public static class TupleMapper
    {

        public static T Map<T>(object source) where T : ITuple
        {
            var itemTypes = typeof(T).GenericTypeArguments;
            var values = itemTypes.Select(itemType =>
                Mapper.Map(source, source.GetType(), itemType)).ToArray();
            return (T)Activator.CreateInstance(typeof(T), values);
        }

    }

    internal class MyProfile
        : Profile
    {

        public MyProfile()
        {
            this.CreateMap<AModel, BModel>()
                .ForMember(x => x.Field3, x => x.MapFrom(z => z.Field1 + "_b"))
                .ForMember(x => x.Field4, x => x.MapFrom(z => z.Field2 + "_b"));
            this.CreateMap<AModel, CModel>()
                .ForMember(x => x.Field5, x => x.MapFrom(z => z.Field1 + "_c"))
                .ForMember(x => x.Field6, x => x.MapFrom(z => z.Field2 + "_c"));
        }

    }

    internal class Program
    {

        private static void Main(string[] args)
        {
            Mapper.Initialize(config => config.AddProfile<MyProfile>());

            var a = new AModel()
            {
                Field1 = "a",
                Field2 = "b"
            };

            var (b1, b2) = TupleMapper.Map<Tuple<BModel, BModel>>(a);

            var (b3, b4, c1) = TupleMapper.Map<Tuple<BModel, BModel, CModel>>(a);

            Console.WriteLine("Result 1:");
            Console.WriteLine($"b1: {b1.ToString()}");
            Console.WriteLine($"b2: {b2.ToString()}");

            Console.WriteLine("Result 2:");
            Console.WriteLine($"b3: {b3.ToString()}");
            Console.WriteLine($"b4: {b4.ToString()}");
            Console.WriteLine($"c1: {c1.ToString()}");

            Console.ReadKey();
        }

    }

}
